
Using Gimp (*.xcf)



Notes: 
store App images in image/export folder


Images List:
splash.png (size 128+)

logo.png (150)

// must be gif to work with windows (??)
icon.gif (32)
iconServer.gif (32)
iconClient.gif (32)

for each root (/toolbar)
    *Splash.png (128)
    *Button.png (48)
    *Bar.png (24)


get icons (choose free option)      
    www.iconbuddy.app
    www.thenounproject.com
    www.iconfinder.com
    www.streamlinehq.com
        custom settings:  size=128,  stroke=8

colors
    color wheel
        http://www.mpsaz.org/skyline/staff/jamuth/project-1/

    jfc blue 6382bf 
    jfc light blue b8cfe5
    darker blue 0c1878           
    darker red db2813
    darker orange fc9a04
        

images needed to be copied to:
    directory: src/.../view/image
        splash.png 
        icon.gif
        iconServer.gif
        iconClient.gif

    directory: src/.../view/oa/image
        OABuilder generates the following icons based on the model UI tree.
            *Splash.png 
            *Button.png
            *Bar.png

    directory: src/.../report/html
        logo.jpg
        
    directory: src/.../help/image
        splash.png
        icon.gif    
    
Note:  to create screen shots, use ^+[F11] in the Client to be able to click labels on glassframe   
    


    
    
    
