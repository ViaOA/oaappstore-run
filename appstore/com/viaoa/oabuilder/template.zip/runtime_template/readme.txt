
the "runtime" directory should not be included in git commits - add to .gitignore

runtime/client|server|single all have a data directory that saves the application data until a database is used.

see doc/readme.txt