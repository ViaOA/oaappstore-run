


For custom reports:

see:
src\main\java\com\template\report

    ..\html\sample has html, css for custom sales order report
    
    ..\oa\sample has java code for custom sales order report
     
SalesOrderReport.pdf is a sample
