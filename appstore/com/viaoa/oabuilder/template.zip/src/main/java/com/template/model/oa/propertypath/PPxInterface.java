// Copied from OATemplate project by OABuilder 07/01/16 07:41 AM
package com.template.model.oa.propertypath;

public interface PPxInterface {
}
