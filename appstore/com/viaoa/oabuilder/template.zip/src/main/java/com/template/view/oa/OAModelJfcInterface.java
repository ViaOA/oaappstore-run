package com.template.view.oa;

import com.viaoa.hub.Hub;
import com.viaoa.object.OAObjectModel;

public interface OAModelJfcInterface {

    public Hub<?> getHub();
    
    public OAObjectModel getModel();
    
    

}
