package com.template.delegate;

public class UserAccessDelegate {
    
    
}
