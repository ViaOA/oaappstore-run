package com.template.control.client;

public class ClientObjectController {
    public ClientObjectController() {
    }
}
